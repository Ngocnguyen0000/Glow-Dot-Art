
import React, { useState, useCallback, useRef } from 'react';
import { processSVG } from './services/svgProcessor';
import { Explanation } from './components/Explanation';
import DotPreview from './components/DotPreview';

const App: React.FC = () => {
    const [svgContent, setSvgContent] = useState<string | null>(null);
    const [svgFileName, setSvgFileName] = useState<string>('');
    const [coordinates, setCoordinates] = useState<string>('');
    const [epsilon, setEpsilon] = useState<number>(1);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [isCopied, setIsCopied] = useState<boolean>(false);
    const [previewMode, setPreviewMode] = useState<'svg' | 'dots'>('svg');

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && file.type === "image/svg+xml") {
            const reader = new FileReader();
            reader.onload = (e) => {
                const text = e.target?.result as string;
                setSvgContent(text);
                setSvgFileName(file.name);
                setCoordinates('');
                setError(null);
                setPreviewMode('svg');
            };
            reader.readAsText(file);
        } else {
            setError("Please select a valid SVG file.");
            setSvgContent(null);
            setSvgFileName('');
        }
    };

    const handleProcess = useCallback(async () => {
        if (!svgContent) {
            setError("No SVG file loaded.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setCoordinates('');
        try {
            const result = await processSVG(svgContent, epsilon);
            setCoordinates(result);
            if (result) {
                setPreviewMode('dots');
            }
        } catch (err: any) {
            setError(err.message || "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    }, [svgContent, epsilon]);

    const handleCopyToClipboard = () => {
        if (coordinates) {
            navigator.clipboard.writeText(coordinates);
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        }
    };

    const triggerFileSelect = () => {
        fileInputRef.current?.click();
    };

    const TabButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
        <button
            onClick={onClick}
            className={`px-4 py-2 text-lg font-semibold transition-colors duration-200 focus:outline-none ${
                active 
                ? 'text-cyan-400 border-b-2 border-cyan-400' 
                : 'text-gray-400 hover:text-white border-b-2 border-transparent'
            }`}
        >
            {children}
        </button>
    );

    return (
        <div className="min-h-screen bg-gray-900 text-gray-100 font-sans p-4 sm:p-8">
            <div className="max-w-7xl mx-auto">
                <header className="text-center mb-10">
                    <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600">
                        SVG Dot-to-Dot Generator
                    </h1>
                    <p className="mt-4 text-lg text-gray-400 max-w-2xl mx-auto">
                        Upload an SVG, and this tool will extract and simplify its geometry into a connect-the-dots coordinate list.
                    </p>
                </header>

                <main className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left Column: Controls & Output */}
                    <div className="lg:col-span-1 bg-gray-800 p-6 rounded-xl shadow-2xl border border-gray-700 flex flex-col space-y-6">
                        <div>
                            <h2 className="text-2xl font-bold mb-4 text-white">1. Upload SVG</h2>
                             <input
                                type="file"
                                accept="image/svg+xml"
                                onChange={handleFileChange}
                                className="hidden"
                                ref={fileInputRef}
                            />
                            <button
                                onClick={triggerFileSelect}
                                className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded-lg transition duration-300 ease-in-out flex items-center justify-center"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                                {svgFileName ? `Loaded: ${svgFileName}` : 'Select SVG File'}
                            </button>
                        </div>
                        
                        <div>
                            <h2 className="text-2xl font-bold mb-2 text-white">2. Configure</h2>
                            <label htmlFor="epsilon" className="block mb-2 font-medium text-gray-300">
                                Simplification (Epsilon): {epsilon.toFixed(1)}
                            </label>
                            <input
                                id="epsilon"
                                type="range"
                                min="0.1"
                                max="10"
                                step="0.1"
                                value={epsilon}
                                onChange={(e) => setEpsilon(parseFloat(e.target.value))}
                                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                            />
                             <p className="text-sm text-gray-500 mt-1">Lower values mean more detail and more points.</p>
                        </div>
                        
                        <button
                            onClick={handleProcess}
                            disabled={!svgContent || isLoading}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold py-4 px-4 rounded-lg transition duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center text-lg"
                        >
                            {isLoading ? (
                                <>
                                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    Processing...
                                </>
                            ) : 'Generate Coordinates'}
                        </button>
                        {error && <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg">{error}</div>}
                        
                         {/* Output */}
                        <div className="flex-grow flex flex-col">
                            <h2 className="text-2xl font-bold mb-4 text-white">3. Output Coordinates</h2>
                            <div className="relative flex-grow">
                                <pre className="bg-gray-900 text-yellow-300 p-4 rounded-lg text-sm overflow-auto h-full min-h-[15rem]">
                                    <code>
                                        {coordinates ? coordinates : 'Your generated coordinates will appear here...'}
                                    </code>
                                </pre>
                                {coordinates && (
                                    <button
                                        onClick={handleCopyToClipboard}
                                        className="absolute top-2 right-2 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-1 px-3 rounded-md text-xs transition"
                                    >
                                        {isCopied ? 'Copied!' : 'Copy'}
                                    </button>
                                )}
                            </div>
                        </div>

                    </div>

                    {/* Right Column: Previews */}
                    <div className="lg:col-span-2 bg-gray-800 p-6 rounded-xl shadow-2xl border border-gray-700 flex flex-col">
                        <div className="flex border-b border-gray-700 mb-4">
                            <TabButton active={previewMode === 'svg'} onClick={() => setPreviewMode('svg')}>
                                Original SVG
                            </TabButton>
                             <TabButton active={previewMode === 'dots'} onClick={() => setPreviewMode('dots')}>
                                Dot-to-Dot Preview
                            </TabButton>
                        </div>
                        <div className="flex-grow bg-gray-900 p-4 rounded-lg border border-gray-600 flex items-center justify-center min-h-[28rem]">
                             {previewMode === 'svg' && (
                                <>
                                    {svgContent ? (
                                         <div className="w-full h-full" dangerouslySetInnerHTML={{ __html: svgContent }} />
                                    ) : (
                                        <div className="text-gray-500">Upload an SVG to see the preview.</div>
                                    )}
                                </>
                            )}
                             {previewMode === 'dots' && (
                                <DotPreview coordinates={coordinates} />
                            )}
                        </div>
                    </div>
                </main>
                
                <Explanation />
            </div>
        </div>
    );
};

export default App;
