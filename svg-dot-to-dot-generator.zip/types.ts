
export type Point = [number, number];
export type ProcessedPoint = [number, number] | [number, number, -1];
