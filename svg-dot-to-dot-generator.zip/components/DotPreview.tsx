
import React, { useMemo } from 'react';

interface DotPreviewProps {
    coordinates: string;
}

type Shape = {
    points: [number, number][];
    isClosed: boolean;
};

const DotPreview: React.FC<DotPreviewProps> = ({ coordinates }) => {
    const shapes = useMemo(() => {
        if (!coordinates.trim()) {
            return [];
        }

        const shapeStrings = coordinates.trim().split(/\n\s*\n/);
        const parsedShapes: Shape[] = [];

        shapeStrings.forEach(shapeStr => {
            try {
                // The string is like `[x,y], [x,y, -1]`. Wrap in `[]` to make it a valid JSON array.
                const pointsArray: ([number, number] | [number, number, -1])[] = JSON.parse(`[${shapeStr}]`);

                if (pointsArray.length > 0) {
                    const shape: Shape = { points: [], isClosed: false };
                    
                    pointsArray.forEach((p, index) => {
                        shape.points.push([p[0], p[1]]);
                        if (p.length === 3 && p[2] === -1 && index === pointsArray.length - 1) {
                            shape.isClosed = true;
                        }
                    });
                    parsedShapes.push(shape);
                }
            } catch (e) {
                console.error("Failed to parse coordinates for preview:", e);
                // Gracefully fail for this shape
            }
        });
        return parsedShapes;
    }, [coordinates]);

    const viewBox = useMemo(() => {
        if (shapes.length === 0) {
            return '0 0 100 100';
        }

        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        shapes.forEach(shape => {
            shape.points.forEach(([x, y]) => {
                if (x < minX) minX = x;
                if (y < minY) minY = y;
                if (x > maxX) maxX = x;
                if (y > maxY) maxY = y;
            });
        });

        if (minX === Infinity || (minX === maxX && minY === maxY)) {
             // Handle single point case or empty shapes
            const x = minX === Infinity ? 50 : minX;
            const y = minY === Infinity ? 50 : minY;
            return `${x-50} ${y-50} 100 100`;
        }

        const padding = (maxX - minX + maxY - minY) * 0.05; // 5% padding
        const width = (maxX - minX) + padding * 2;
        const height = (maxY - minY) + padding * 2;
        
        return `${minX - padding} ${minY - padding} ${width} ${height}`;
    }, [shapes]);

    // FIX: Moved this hook before the conditional return to fix React Error #300.
    // All hooks must be called in the same order on every render.
    const strokeWidth = useMemo(() => {
        const [, , vbWidth] = (viewBox.split(' ').map(parseFloat));
        return (vbWidth || 100) / 200;
    }, [viewBox]);


    if (shapes.length === 0) {
        return <div className="flex items-center justify-center h-full text-gray-500">No data to preview. Generate coordinates first.</div>;
    }

    return (
        <svg viewBox={viewBox} className="w-full h-full" preserveAspectRatio="xMidYMid meet">
            {shapes.map((shape, shapeIndex) => (
                <g key={shapeIndex}>
                    <polyline
                        points={shape.points.map(p => p.join(',')).join(' ')}
                        fill="none"
                        stroke="rgba(110, 231, 183, 0.7)"
                        strokeWidth={strokeWidth}
                        strokeLinejoin="round"
                        strokeLinecap="round"
                    />
                    {shape.points.map(([x, y], pointIndex) => (
                        <circle
                            key={pointIndex}
                            cx={x}
                            cy={y}
                            r={strokeWidth * 1.5}
                            fill="#f59e0b"
                        />
                    ))}
                </g>
            ))}
        </svg>
    );
};

export default DotPreview;
